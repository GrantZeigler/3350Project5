// Quick Sort mid

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdio.h>
#include <bits/stdc++.h> 
#include <sys/time.h> 

using namespace std;
int comparison = 0;
int numbersCount = 0;
int timeCount = 0;

int partition(vector<int> &nums, int p, int r)
{
    
    int pivot = nums[r]; 
    int i = (p - 1); 
 
    for (int j = p; j <= r - 1; j++) 
    {
         if (nums[j] <= pivot) {
 
            i++; 
            swap(nums[i], nums[j]);
            comparison++;
        }
    }
    swap(nums[i + 1], nums[r]);
    comparison++;
    return (i + 1);
}

int partitionRand(vector<int> &nums, int p, int r){
    
    int mid = (r - p)/2;
    swap(nums[r], nums[mid]);
    comparison++;

    return partition(nums, p, r);
}


void quickSort(vector<int> &nums, int p, int r){
if (p < r)
    {
        int q = partition(nums, p, r);
        quickSort(nums, p, q - 1);
        quickSort(nums, q + 1, r);

    }
}

int main() {
//Time tracking from
// https://www.geeksforgeeks.org/measure-execution-time-with-high-precision-in-c-c/    

    string filePath;
    
    cout << "File path for file to be sorted: " << endl;
    cin >> filePath;
    
    //File Reading source Code from
    //http://www.cplusplus.com/forum/beginner/17845/

    
    vector<int> numbers;

    //Create an input file stream
    ifstream inFile(filePath,ios::in);
    int number; 
    while (inFile >> number) {
        numbers.push_back(number);
    }
numbersCount = numbers.size();
    //Close the file stream
    inFile.close();
    struct timespec start, end;
     clock_gettime(CLOCK_MONOTONIC, &start); 
    ios_base::sync_with_stdio(false);
    quickSort(numbers, 0, numbers.size());
     clock_gettime(CLOCK_MONOTONIC, &end);
    //Display info
    double timeCount; 
    timeCount = (end.tv_sec - start.tv_sec) * 1e9; 
    timeCount = (timeCount + (end.tv_nsec - start.tv_nsec)) * 1e-9;  
    cout << "Numbers, comparisons, and time: ";
    cout << numbersCount << " " << comparison << " ";
    cout << timeCount << setprecision(9);

     //Use of app from
    //http://www.cplusplus.com/reference/fstream/ofstream/open/
    ofstream outfile("output.txt", ios::app);
    outfile << numbersCount << " " << comparison << " ";
    outfile << timeCount << setprecision(9) << "\n";
    outfile.close();

    return 0;
}

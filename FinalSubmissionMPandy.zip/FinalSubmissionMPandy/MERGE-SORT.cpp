// Merge Sort

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdio.h>
#include <bits/stdc++.h> 
#include <sys/time.h> 
#include <limits.h>

using namespace std;
int comparison = 0;
int numbersCount = 0;
int timeCount = 0;

void merge(vector<int> &nums, int p, int q, int r) 
{ 
    int n1 = q - p + 1; 
    int n2 = r - q; 
    
    int L[n1 + 1], R[n2 + 1]; 
  
    for(int i = 1; i < n1; i++) 
        L[i] = nums[p + i]; 
    for(int j = 1; j < n2; j++) 
        R[j] = nums[q + 1 + j]; 
    
    L[n1 + 1] = INT_MAX;
    R[n2 + 1] = INT_MAX;
    int i = 1;
    int j = 1;
    for (int k = p; k < r; k++)  
        {
        if (L[i] <= R[j])
            {
                 nums[k] = L[i];
                 comparison++;
                 i = i + 1;
            }
        else
            {
                 nums[k] = R[j];
                 comparison++;
                 j = j + 1;
            }
        }


} 

void mergeSort(vector<int> &nums, int p, int r)  
{  
    if (p < r) {  
  
        int q = p + (r - p) / 2;   
  ///home/93/mpandy/DATASETS/SORTED-10000.txt
        mergeSort(nums, p, q);  
        mergeSort(nums, q + 1, r);  
  
        merge(nums, p, q, r);  
    }  
}  
  



int main() {
//Time tracking from
// https://www.geeksforgeeks.org/measure-execution-time-with-high-precision-in-c-c/    

    string filePath;
    
    cout << "File path for file to be sorted: " << endl;
    cin >> filePath;
    
    //File Reading source Code from
    //http://www.cplusplus.com/forum/beginner/17845/

    
    vector<int> numbers;

    //Create an input file stream
    ifstream inFile(filePath,ios::in);
    int number; 
    while (inFile >> number) {
        numbers.push_back(number);
    }

    //Close the file stream
    inFile.close();
    numbersCount = numbers.size();
    struct timespec start, end;
     clock_gettime(CLOCK_MONOTONIC, &start); 
    ios_base::sync_with_stdio(false);
    mergeSort(numbers, 0, numbers.size());
     clock_gettime(CLOCK_MONOTONIC, &end);
    //Display info
    double timeCount; 
    timeCount = (end.tv_sec - start.tv_sec) * 1e9; 
    timeCount = (timeCount + (end.tv_nsec - start.tv_nsec)) * 1e-9;  
    cout << "Numbers, comparisons, and time: ";
    cout << numbersCount << " " << comparison << " ";
    cout << timeCount << setprecision(9);

      //Use of app from
    //http://www.cplusplus.com/reference/fstream/ofstream/open/
    ofstream outfile("output.txt", ios::app);
    outfile << numbersCount << " " << comparison << " ";
    outfile << timeCount << setprecision(9) << "\n";
    outfile.close();

    return 0;
}

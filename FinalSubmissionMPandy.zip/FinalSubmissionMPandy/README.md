run each file with:
g++ INSERTION-SORT.cpp -o insert
./insert
(directory) i.e /home/93/mpandy/DATASETS/(wanted data file)

g++ QUICKSORT.cpp -o quick
./quick
(directory) i.e /home/93/mpandy/DATASETS/(wanted data file)

g++ QUICKSORT-MID.cpp -o quickmid
./quickmid
(directory) i.e /home/93/mpandy/DATASETS/(wanted data file)

g++ MERGE-SORT.cpp -o merge
./merge
(directory) i.e /home/93/mpandy/DATASETS/(wanted data file)

